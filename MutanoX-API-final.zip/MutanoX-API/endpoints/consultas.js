/**
 * Endpoint: Consultas (CPF, Nome, Número, etc)
 * Rota: /api/consultas
 * @author @MutanoX
 */

const logger = require('../logger');

// Parsers de dados
function parseCPFData(text) {
  const data = {
    dadosBasicos: {},
    dadosEconomicos: {},
    enderecos: [],
    tituloEleitor: {},
    dadosFiscais: {},
    beneficiosSociais: [],
    pessoaExpostaPoliticamente: {},
    servidorPublico: {},
    perfilConsumo: {},
    vacinas: [],
    informacoesImportantes: {}
  };

  const nomeMatch = text.match(/• Nome: (.+)/);
  if (nomeMatch) data.dadosBasicos.nome = nomeMatch[1].trim();

  const cpfMatch = text.match(/• CPF: (\d+)/);
  if (cpfMatch) data.dadosBasicos.cpf = cpfMatch[1];

  const cnsMatch = text.match(/• CNS: (\d+)/);
  if (cnsMatch) data.dadosBasicos.cns = cnsMatch[1];

  const dataNascimentoMatch = text.match(/• Data de Nascimento: (.+)/);
  if (dataNascimentoMatch) data.dadosBasicos.dataNascimento = dataNascimentoMatch[1].trim();

  const sexoMatch = text.match(/• Sexo: (.+)/);
  if (sexoMatch) data.dadosBasicos.sexo = sexoMatch[1].trim();

  const nomeMaeMatch = text.match(/• Nome da Mãe: (.+)/);
  if (nomeMaeMatch) data.dadosBasicos.nomeMae = nomeMaeMatch[1].trim();

  const nomePaiMatch = text.match(/• Nome do Pai: (.+)/);
  if (nomePaiMatch) data.dadosBasicos.nomePai = nomePaiMatch[1].trim();

  const situacaoCadastralMatch = text.match(/• Situação Cadastral: (.+)/);
  if (situacaoCadastralMatch) data.dadosBasicos.situacaoCadastral = situacaoCadastralMatch[1].trim();

  const dataSituacaoMatch = text.match(/• Data da Situação: (.+)/);
  if (dataSituacaoMatch) data.dadosBasicos.dataSituacao = dataSituacaoMatch[1].trim();

  const rendaMatch = text.match(/• Renda: (.+)/);
  if (rendaMatch) data.dadosEconomicos.renda = rendaMatch[1].trim();

  const poderAquisitivoMatch = text.match(/• Poder Aquisitivo: (.+)/);
  if (poderAquisitivoMatch) data.dadosEconomicos.poderAquisitivo = poderAquisitivoMatch[1].trim();

  const faixaRendaMatch = text.match(/• Faixa de Renda: (.+)/);
  if (faixaRendaMatch) data.dadosEconomicos.faixaRenda = faixaRendaMatch[1].trim();

  const scoreMatch = text.match(/• Score CSBA: (.+)/);
  if (scoreMatch) data.dadosEconomicos.scoreCSBA = scoreMatch[1].trim();

  const addressBlocks = text.split('🏠 ENDEREÇO');
  for (let i = 1; i < addressBlocks.length; i++) {
    const endereco = {};
    const logradouroMatch = addressBlocks[i].match(/• Logradouro:\s*(.+)/);
    if (logradouroMatch) endereco.logradouro = logradouroMatch[1].trim();

    const bairroMatch = addressBlocks[i].match(/• Bairro:\s*(.+)/);
    if (bairroMatch) endereco.bairro = bairroMatch[1].trim();

    const cidadeMatch = addressBlocks[i].match(/• Cidade\/UF:\s*(.+)/);
    if (cidadeMatch) endereco.cidadeUF = cidadeMatch[1].trim();

    const cepMatch = addressBlocks[i].match(/• CEP:\s*(.+)/);
    if (cepMatch) endereco.cep = cepMatch[1].trim();

    if (Object.keys(endereco).length > 0) {
      data.enderecos.push(endereco);
    }
  }

  const cpfValidoMatch = text.match(/• CPF Válido: (.+)/);
  if (cpfValidoMatch) data.informacoesImportantes.cpfValido = cpfValidoMatch[1].trim();

  const obitoInfoMatch = text.match(/• Óbito: (.+)/);
  if (obitoInfoMatch) data.informacoesImportantes.obito = obitoInfoMatch[1].trim();

  const pepInfoMatch = text.match(/• PEP: (.+)/);
  if (pepInfoMatch) data.informacoesImportantes.pep = pepInfoMatch[1].trim();

  return data;
}

// Handlers de consultas
async function consultarCPF(cpf) {
  try {
    logger.debug(`Consultando CPF: ${cpf}`);
    const response = await fetch(`https://world-ecletix.onrender.com/api/consultarcpf?cpf=${cpf}`, {
      timeout: 30000
    });
    const data = await response.json();
    const parsedData = parseCPFData(data.resultado);
    
    return {
      sucesso: true,
      dados: parsedData,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao consultar CPF', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

async function consultarNome(nome) {
  try {
    logger.debug(`Consultando nome: ${nome}`);
    const response = await fetch(`https://world-ecletix.onrender.com/api/nome-completo?q=${encodeURIComponent(nome)}`, {
      timeout: 30000
    });
    const data = await response.json();
    
    return {
      sucesso: true,
      dados: data,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao consultar nome', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

async function consultarNumero(numero) {
  try {
    logger.debug(`Consultando número: ${numero}`);
    const response = await fetch(`https://world-ecletix.onrender.com/api/numero?q=${encodeURIComponent(numero)}`, {
      timeout: 30000
    });
    const data = await response.json();
    
    return {
      sucesso: true,
      dados: data,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao consultar número', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

module.exports = {
  name: 'consultas',
  routes: {
    'GET /api/consultas': async (req, res, query) => {
      const tipo = query.tipo;

      if (!tipo) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Tipo de consulta não informado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      let result;

      if (tipo === 'cpf') {
        const cpf = query.cpf;
        if (!cpf) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            sucesso: false,
            erro: 'CPF não informado',
            criador: '@MutanoX'
          }, null, 2));
          return;
        }
        result = await consultarCPF(cpf);
      } else if (tipo === 'nome') {
        const nome = query.q;
        if (!nome) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            sucesso: false,
            erro: 'Nome não informado',
            criador: '@MutanoX'
          }, null, 2));
          return;
        }
        result = await consultarNome(nome);
      } else if (tipo === 'numero') {
        const numero = query.q;
        if (!numero) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            sucesso: false,
            erro: 'Número não informado',
            criador: '@MutanoX'
          }, null, 2));
          return;
        }
        result = await consultarNumero(numero);
      } else {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Tipo de consulta inválido',
          tiposDisponiveis: ['cpf', 'nome', 'numero'],
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    }
  }
};
