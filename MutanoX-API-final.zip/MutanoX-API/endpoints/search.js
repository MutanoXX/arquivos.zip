/**
 * Endpoint: Buscas (GitHub, Pinterest, YouTube, etc)
 * Rota: /api/search
 * @author @MutanoX
 */

const logger = require('../logger');

// Handlers de busca
async function githubSearch(username, apikey) {
  try {
    logger.debug(`Buscando usuário GitHub: ${username}`);
    const response = await fetch(`https://anabot.my.id/api/search/githubSearch?username=${encodeURIComponent(username)}&apikey=${encodeURIComponent(apikey)}`, {
      timeout: 30000
    });
    const data = await response.json();
    
    return {
      sucesso: data.success || true,
      dados: data,
      username,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao buscar GitHub', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

async function googleImage(query, apikey) {
  try {
    logger.debug(`Buscando imagens Google: ${query}`);
    const response = await fetch(`https://anabot.my.id/api/search/gimage?query=${encodeURIComponent(query)}&apikey=${encodeURIComponent(apikey)}`, {
      timeout: 30000
    });
    const data = await response.json();
    
    return {
      sucesso: data.success || true,
      dados: data,
      query,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao buscar imagens', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

async function pinterestSearch(query, apikey) {
  try {
    logger.debug(`Buscando Pinterest: ${query}`);
    const response = await fetch(`https://anabot.my.id/api/search/pinterest?query=${encodeURIComponent(query)}&apikey=${encodeURIComponent(apikey)}`, {
      timeout: 30000
    });
    const data = await response.json();
    
    return {
      sucesso: data.success || true,
      dados: data,
      query,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao buscar Pinterest', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

async function robloxSearch(username, apikey) {
  try {
    logger.debug(`Buscando Roblox: ${username}`);
    const response = await fetch(`https://anabot.my.id/api/search/robloxStalk?username=${encodeURIComponent(username)}&apikey=${encodeURIComponent(apikey)}`, {
      timeout: 30000
    });
    const data = await response.json();
    
    return {
      sucesso: data.success || true,
      dados: data,
      username,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao buscar Roblox', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

async function tiktokSearch(username, apikey) {
  try {
    logger.debug(`Buscando TikTok: ${username}`);
    const response = await fetch(`https://anabot.my.id/api/search/tiktokSearch?username=${encodeURIComponent(username)}&apikey=${encodeURIComponent(apikey)}`, {
      timeout: 30000
    });
    const data = await response.json();
    
    return {
      sucesso: data.success || true,
      dados: data,
      username,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao buscar TikTok', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

async function youtubeSearch(query, apikey) {
  try {
    logger.debug(`Buscando YouTube: ${query}`);
    const response = await fetch(`https://anabot.my.id/api/search/ytSearch?query=${encodeURIComponent(query)}&apikey=${encodeURIComponent(apikey)}`, {
      timeout: 30000
    });
    const data = await response.json();
    
    return {
      sucesso: data.success || true,
      dados: data,
      query,
      criador: '@MutanoX'
    };
  } catch (error) {
    logger.error('Erro ao buscar YouTube', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

module.exports = {
  name: 'search',
  routes: {
    'GET /api/search/github': async (req, res, query) => {
      const username = query.username;
      const apikey = query.apikey;

      if (!username) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Username não informado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = await githubSearch(username, apikey);
      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    },

    'GET /api/search/gimage': async (req, res, query) => {
      const q = query.q;
      const apikey = query.apikey;

      if (!q) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Query não informada',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = await googleImage(q, apikey);
      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    },

    'GET /api/search/pinterest': async (req, res, query) => {
      const q = query.q;
      const apikey = query.apikey;

      if (!q) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Query não informada',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = await pinterestSearch(q, apikey);
      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    },

    'GET /api/search/roblox': async (req, res, query) => {
      const username = query.username;
      const apikey = query.apikey;

      if (!username) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Username não informado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = await robloxSearch(username, apikey);
      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    },

    'GET /api/search/tiktok': async (req, res, query) => {
      const username = query.username;
      const apikey = query.apikey;

      if (!username) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Username não informado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = await tiktokSearch(username, apikey);
      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    },

    'GET /api/search/youtube': async (req, res, query) => {
      const q = query.q;
      const apikey = query.apikey;

      if (!q) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Query não informada',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = await youtubeSearch(q, apikey);
      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    }
  }
};
