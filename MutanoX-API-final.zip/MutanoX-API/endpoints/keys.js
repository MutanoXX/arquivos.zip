/**
 * Endpoint: Gerenciamento de API Keys
 * Rota: /api/keys/*
 * @author @MutanoX
 */

const keyManager = require('../keyManager');
const logger = require('../logger');
const config = require('../config');

module.exports = {
  name: 'keys',
  routes: {
    // GET /api/keys/list - Listar todas as chaves (apenas admin)
    'GET /api/keys/list': async (req, res, query) => {
      const adminKey = query.adminkey || req.headers['x-admin-key'];

      if (adminKey !== config.ADMIN_KEY) {
        logger.warning('Tentativa de acesso não autorizado ao endpoint de keys', { 
          ip: req.socket.remoteAddress 
        });
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Acesso negado. Chave admin inválida.',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = keyManager.listKeys(adminKey);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        sucesso: result.success,
        ...result,
        criador: '@MutanoX'
      }, null, 2));
    },

    // POST /api/keys/create - Criar nova chave
    'POST /api/keys/create': async (req, res, query, body) => {
      const adminKey = query.adminkey || req.headers['x-admin-key'];

      if (adminKey !== config.ADMIN_KEY) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Acesso negado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      try {
        const data = JSON.parse(body);
        const { name, type = 'standard', rateLimit = 30, requestLimit = 1000 } = data;

        if (!name) {
          res.writeHead(400, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            sucesso: false,
            erro: 'Nome da chave é obrigatório',
            criador: '@MutanoX'
          }, null, 2));
          return;
        }

        const newKey = keyManager.createKey(name, type, rateLimit, requestLimit);
        
        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: true,
          chave: newKey,
          criador: '@MutanoX'
        }, null, 2));

      } catch (error) {
        logger.error('Erro ao criar chave', error.message);
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Erro ao processar requisição',
          criador: '@MutanoX'
        }, null, 2));
      }
    },

    // DELETE /api/keys/delete - Deletar chave
    'DELETE /api/keys/delete': async (req, res, query) => {
      const adminKey = query.adminkey || req.headers['x-admin-key'];
      const keyToDelete = query.key;

      if (adminKey !== config.ADMIN_KEY) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Acesso negado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      if (!keyToDelete) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Chave não informada',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = keyManager.deleteKey(keyToDelete);
      
      res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        sucesso: result.success,
        ...result,
        criador: '@MutanoX'
      }, null, 2));
    },

    // PUT /api/keys/update - Atualizar chave
    'PUT /api/keys/update': async (req, res, query, body) => {
      const adminKey = query.adminkey || req.headers['x-admin-key'];
      const keyToUpdate = query.key;

      if (adminKey !== config.ADMIN_KEY) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Acesso negado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      try {
        const updates = JSON.parse(body);
        const result = keyManager.updateKey(keyToUpdate, updates, adminKey);
        
        res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: result.success,
          ...result,
          criador: '@MutanoX'
        }, null, 2));

      } catch (error) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Erro ao processar requisição',
          criador: '@MutanoX'
        }, null, 2));
      }
    },

    // POST /api/keys/deactivate - Desativar chave
    'POST /api/keys/deactivate': async (req, res, query) => {
      const adminKey = query.adminkey || req.headers['x-admin-key'];
      const keyToDeactivate = query.key;

      if (adminKey !== config.ADMIN_KEY) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Acesso negado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = keyManager.deactivateKey(keyToDeactivate);
      
      res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        sucesso: result.success,
        ...result,
        criador: '@MutanoX'
      }, null, 2));
    },

    // POST /api/keys/activate - Ativar chave
    'POST /api/keys/activate': async (req, res, query) => {
      const adminKey = query.adminkey || req.headers['x-admin-key'];
      const keyToActivate = query.key;

      if (adminKey !== config.ADMIN_KEY) {
        res.writeHead(403, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Acesso negado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = keyManager.activateKey(keyToActivate);
      
      res.writeHead(result.success ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        sucesso: result.success,
        ...result,
        criador: '@MutanoX'
      }, null, 2));
    }
  }
};
