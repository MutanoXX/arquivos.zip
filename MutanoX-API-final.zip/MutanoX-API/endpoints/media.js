/**
 * Endpoint: Geração de Mídia (NSFW, Vídeo, etc)
 * Rota: /api/media
 * @author @MutanoX
 */

const logger = require('../logger');
const mediaManager = require('../mediaManager');

// Handlers de geração de mídia
async function nsfwImageGen(prompt, negative = '', apikey) {
  try {
    logger.debug(`Gerando imagem NSFW: ${prompt}`);

    const response = await fetch('https://anabot.my.id/api/generate/nsfw', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prompt,
        negative,
        apikey
      }),
      timeout: 60000
    });

    if (!response.ok) {
      throw new Error(`Erro na API: ${response.status}`);
    }

    const data = await response.json();

    if (!data.success || !data.data?.result) {
      throw new Error('Resposta inválida da API');
    }

    // Download e hospedagem local da imagem
    const mediaResult = await mediaManager.downloadAndHost(data.data.result, 'nsfw');

    if (!mediaResult.success) {
      throw new Error(mediaResult.error);
    }

    logger.success(`Imagem NSFW gerada e hospedada: ${mediaResult.mediaId}`);

    return {
      sucesso: true,
      dados: {
        prompt,
        negative,
        imageUrl: mediaResult.localUrl,
        mediaId: mediaResult.mediaId,
        size: mediaResult.size
      },
      criador: '@MutanoX'
    };

  } catch (error) {
    logger.error('Erro ao gerar imagem NSFW', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

async function textToVideo(prompt, quality = '1080p', ratio = '9:16', apikey) {
  try {
    logger.debug(`Gerando vídeo: ${prompt}`);

    const response = await fetch('https://anabot.my.id/api/generate/video', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({
        prompt,
        quality,
        ratio,
        apikey
      }),
      timeout: 120000
    });

    if (!response.ok) {
      throw new Error(`Erro na API: ${response.status}`);
    }

    const data = await response.json();

    return {
      sucesso: data.success || true,
      dados: data.data || data,
      criador: '@MutanoX'
    };

  } catch (error) {
    logger.error('Erro ao gerar vídeo', error.message);
    return {
      sucesso: false,
      erro: error.message,
      criador: '@MutanoX'
    };
  }
}

module.exports = {
  name: 'media',
  routes: {
    'GET /api/media/nsfw': async (req, res, query) => {
      const prompt = query.prompt;
      const negative = query.negative || '';
      const apikey = query.apikey;

      if (!prompt) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Prompt não informado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = await nsfwImageGen(prompt, negative, apikey);
      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    },

    'GET /api/media/video': async (req, res, query) => {
      const prompt = query.prompt;
      const quality = query.quality || '1080p';
      const ratio = query.ratio || '9:16';
      const apikey = query.apikey;

      if (!prompt) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Prompt não informado',
          criador: '@MutanoX'
        }, null, 2));
        return;
      }

      const result = await textToVideo(prompt, quality, ratio, apikey);
      res.writeHead(result.sucesso ? 200 : 400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(result, null, 2));
    }
  }
};
