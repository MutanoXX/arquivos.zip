#!/usr/bin/env node

/**
 * MutanoX API - Cérebro Principal
 * Carregamento dinâmico de endpoints, sistema de API Keys e gerenciamento central
 * 
 * @author @MutanoX
 * @version 2.0.0
 */

const http = require('http');
const url = require('url');
const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');

const config = require('./config');
const logger = require('./logger');
const keyManager = require('./keyManager');
const mediaManager = require('./mediaManager');

// ==========================================
// GERENCIADOR DE ENDPOINTS DINÂMICOS
// ==========================================

class EndpointManager {
  constructor() {
    this.endpoints = {};
    this.watchers = {};
    this.loadEndpoints();
    this.watchEndpoints();
  }

  loadEndpoints() {
    logger.info('Carregando endpoints...');
    
    if (!fs.existsSync(config.DIRS.ENDPOINTS)) {
      fs.mkdirSync(config.DIRS.ENDPOINTS, { recursive: true });
    }

    const files = fs.readdirSync(config.DIRS.ENDPOINTS).filter(f => f.endsWith('.js'));
    
    files.forEach(file => {
      this.loadEndpoint(file);
    });

    logger.success(`${files.length} endpoint(s) carregado(s)`);
  }

  loadEndpoint(filename) {
    const filepath = path.join(config.DIRS.ENDPOINTS, filename);
    
    // Limpar cache do require
    delete require.cache[require.resolve(filepath)];
    
    try {
      const endpoint = require(filepath);
      
      if (!endpoint.routes || typeof endpoint.routes !== 'object') {
        logger.warning(`Endpoint inválido: ${filename} (sem propriedade routes)`);
        return;
      }

      this.endpoints[endpoint.name] = endpoint.routes;
      logger.debug(`Endpoint carregado: ${endpoint.name}`, { 
        routes: Object.keys(endpoint.routes).length 
      });

    } catch (error) {
      logger.error(`Erro ao carregar endpoint ${filename}`, error.message);
    }
  }

  watchEndpoints() {
    const watcher = fs.watch(config.DIRS.ENDPOINTS, (eventType, filename) => {
      if (!filename || !filename.endsWith('.js')) return;

      logger.info(`Detectada mudança em endpoint: ${filename}`);
      
      if (eventType === 'change') {
        this.loadEndpoint(filename);
      } else if (eventType === 'rename') {
        const filepath = path.join(config.DIRS.ENDPOINTS, filename);
        if (!fs.existsSync(filepath)) {
          logger.warning(`Endpoint removido: ${filename}`);
        } else {
          this.loadEndpoint(filename);
        }
      }
    });

    this.watchers.main = watcher;
  }

  getRoute(method, pathname) {
    for (const [, routes] of Object.entries(this.endpoints)) {
      for (const [route, handler] of Object.entries(routes)) {
        const [routeMethod, routePath] = route.split(' ');
        
        if (routeMethod === method && routePath === pathname) {
          return handler;
        }
      }
    }
    return null;
  }

  getAllRoutes() {
    const routes = [];
    for (const [name, routeMap] of Object.entries(this.endpoints)) {
      for (const route of Object.keys(routeMap)) {
        routes.push(route);
      }
    }
    return routes;
  }
}

// ==========================================
// INICIALIZAÇÃO
// ==========================================

const endpointManager = new EndpointManager();

// ==========================================
// SERVIDOR HTTP
// ==========================================

const server = http.createServer(async (req, res) => {
  try {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const query = parsedUrl.query;
    const method = req.method;

    // Log de requisição
    logger.api(method, pathname, 200);

    // Middleware: CORS
    res.setHeader('Access-Control-Allow-Origin', '*');
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE, OPTIONS');
    res.setHeader('Access-Control-Allow-Headers', 'Content-Type, X-API-Key, X-Admin-Key');

    if (method === 'OPTIONS') {
      res.writeHead(200);
      res.end();
      return;
    }

    // Ler body da requisição
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });

    req.on('end', async () => {
      try {
        // Endpoint raiz
        if (pathname === '/' && method === 'GET') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            nome: 'MutanoX API v2.0',
            versao: '2.0.0',
            status: 'online',
            mensagem: 'Bem-vindo à API MutanoX refatorada!',
            endpoints: endpointManager.getAllRoutes(),
            documentacao: 'https://github.com/mutano-x/api-docs',
            criador: '@MutanoX'
          }, null, 2));
          return;
        }

        // Endpoint de status
        if (pathname === '/api/status' && method === 'GET') {
          const stats = mediaManager.getStorageStats();
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            sucesso: true,
            status: 'online',
            uptime: process.uptime(),
            memoria: process.memoryUsage(),
            storage: stats,
            criador: '@MutanoX'
          }, null, 2));
          return;
        }

        // Validação de API Key (exceto para endpoints públicos)
        const publicRoutes = ['/', '/api/status', '/api/keys/list'];
        const isPublic = publicRoutes.includes(pathname);

        if (!isPublic && !pathname.startsWith('/api/keys')) {
          const apiKey = query.apikey || req.headers['x-api-key'];
          
          if (!apiKey) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
              sucesso: false,
              erro: 'API Key não fornecida',
              criador: '@MutanoX'
            }, null, 2));
            return;
          }

          // Validar chave
          const validation = keyManager.validateKey(apiKey);
          if (!validation.valid) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
              sucesso: false,
              erro: validation.error,
              criador: '@MutanoX'
            }, null, 2));
            return;
          }

          // Verificar rate limit
          const rateCheck = keyManager.checkRateLimit(apiKey);
          if (!rateCheck.allowed) {
            res.writeHead(429, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({
              sucesso: false,
              erro: rateCheck.error,
              retryAfter: rateCheck.retryAfter,
              criador: '@MutanoX'
            }, null, 2));
            return;
          }

          logger.debug(`Rate limit OK para ${apiKey}`, { 
            remaining: rateCheck.remaining 
          });
        }

        // Procurar handler para a rota
        const handler = endpointManager.getRoute(method, pathname);

        if (handler) {
          await handler(req, res, query, body);
        } else {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            sucesso: false,
            erro: 'Endpoint não encontrado',
            criador: '@MutanoX'
          }, null, 2));
        }

      } catch (error) {
        logger.error('Erro ao processar requisição', error.message);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({
          sucesso: false,
          erro: 'Erro interno do servidor',
          mensagem: error.message,
          criador: '@MutanoX'
        }, null, 2));
      }
    });

  } catch (error) {
    logger.error('Erro crítico no servidor', error.message);
    res.writeHead(500, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      sucesso: false,
      erro: 'Erro crítico do servidor',
      criador: '@MutanoX'
    }, null, 2));
  }
});

// ==========================================
// INICIAR SERVIDOR
// ==========================================

server.listen(config.PORT, config.HOST, () => {
  logger.banner('MutanoX API v2.0 - Iniciado com Sucesso');
  logger.info(`Servidor rodando em http://${config.HOST}:${config.PORT}`);
  logger.separator();
  logger.info('Endpoints carregados:', endpointManager.getAllRoutes());
  logger.separator();
  logger.info('Admin Key:', config.ADMIN_KEY);
  logger.info('Diretórios:', config.DIRS);
  logger.separator();
  logger.info('Pressione Ctrl+C para parar o servidor');
});

// ==========================================
// TRATAMENTO DE ERROS
// ==========================================

server.on('error', (error) => {
  logger.error('Erro no servidor', error.message);
});

process.on('SIGINT', () => {
  logger.banner('Servidor sendo encerrado...');
  server.close(() => {
    logger.success('Servidor encerrado com sucesso');
    process.exit(0);
  });
});

process.on('uncaughtException', (error) => {
  logger.error('Exceção não capturada', error.message);
});

process.on('unhandledRejection', (reason) => {
  logger.error('Promise rejeitada não tratada', String(reason));
});
