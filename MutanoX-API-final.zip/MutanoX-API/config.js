/**
 * Configurações Globais - MutanoX API
 * @author @MutanoX
 */

const path = require('path');

module.exports = {
  PORT: 8080,
  HOST: 'localhost',
  
  // Diretórios
  DIRS: {
    ENDPOINTS: path.join(__dirname, 'endpoints'),
    NSFW_GEN: path.join(__dirname, 'nsfw-gen'),
    UPLOADS: path.join(__dirname, 'uploads'),
    LOGS: path.join(__dirname, 'logs')
  },

  // Chaves de API padrão
  DEFAULT_KEYS: {
    VIDEO_API_KEY: 'freeApikey',
    IMAGE_API_KEY: 'freeApikey',
    BYPASSCF_API_KEY: 'freeApikey',
    DEFAULT_API_KEY: 'freeApikey'
  },

  // Tipos de bypass disponíveis
  BYPASS_TYPES: [
    'turnstile-min',
    'turnstile-max',
    'source',
    'waf-session',
    'hcaptcha-invisible',
    'recaptcha-v3',
    'recaptcha-v3-enterprise'
  ],

  // Configurações de rate limiting
  RATE_LIMIT: {
    DEFAULT_PER_MINUTE: 30,
    PREMIUM_PER_5_MINUTES: 500,
    ADMIN_UNLIMITED: true
  },

  // Admin Key
  ADMIN_KEY: 'MutanoX3397',

  // URL base para uploads
  UPLOAD_BASE_URL: 'https://mutano-x.discloud.app/api/uploads',

  // Timeouts
  TIMEOUTS: {
    DOWNLOAD: 120000, // 2 minutos
    SEARCH: 60000,    // 1 minuto
    DEFAULT: 30000    // 30 segundos
  }
};
