# MutanoX API v2.0

API refatorada e modular com sistema de gerenciamento de chaves, endpoints dinâmicos e hospedagem local de mídia.

## 🚀 Características Principais

- **Arquitetura Modular**: Endpoints carregados dinamicamente da pasta `/endpoints`
- **Sistema de API Keys**: Gerenciamento completo com rate limiting e limites de requisições
- **Hospedagem Local de Mídia**: Download e hospedagem de imagens NSFW
- **Logs Decorados**: Sistema de logs detalhado com cores e formatação
- **Recarregamento Dinâmico**: Detecta automaticamente mudanças em endpoints
- **Admin Key**: Chave administrativa com poderes ilimitados

## 📁 Estrutura do Projeto

```
MutanoX-API/
├── index.js                 # Cérebro principal (servidor)
├── config.js               # Configurações globais
├── logger.js               # Sistema de logs
├── keyManager.js           # Gerenciador de API Keys
├── mediaManager.js         # Gerenciador de mídia
├── api-keys.json          # Armazenamento de chaves (gerado)
├── endpoints/             # Pasta com endpoints modulares
│   ├── keys.js            # Gerenciamento de chaves
│   ├── consultas.js       # Consultas (CPF, Nome, Número)
│   ├── media.js           # Geração de mídia (NSFW, Vídeo)
│   └── search.js          # Buscas (GitHub, Pinterest, YouTube, etc)
├── nsfw-gen/              # Armazenamento de imagens NSFW
├── uploads/               # Armazenamento de uploads
├── logs/                  # Logs do servidor
└── package.json           # Dependências

```

## 🔧 Instalação

```bash
# Instalar dependências
npm install

# Iniciar servidor
npm start

# Ou em modo desenvolvimento
npm run dev
```

## 📝 Configuração

Edite `config.js` para personalizar:

- **PORT**: Porta do servidor (padrão: 8080)
- **ADMIN_KEY**: Chave administrativa
- **UPLOAD_BASE_URL**: URL base para uploads
- **RATE_LIMIT**: Configurações de rate limiting

## 🔐 Sistema de API Keys

### Chave Admin
```
MutanoX3397
```

A chave admin tem:
- Uso infinito
- Sem rate limite
- Poderes de administrador

### Criar Nova Chave

```bash
curl -X POST http://localhost:8080/api/keys/create \
  -H "Content-Type: application/json" \
  -H "X-Admin-Key: MutanoX3397" \
  -d '{
    "name": "Minha Chave",
    "type": "standard",
    "rateLimit": 30,
    "requestLimit": 1000
  }'
```

### Listar Chaves

```bash
curl http://localhost:8080/api/keys/list?adminkey=MutanoX3397
```

### Deletar Chave

```bash
curl -X DELETE http://localhost:8080/api/keys/delete?adminkey=MutanoX3397&key=MutanoX-xxxxx
```

## 📡 Endpoints Disponíveis

### Consultas
- `GET /api/consultas?tipo=cpf&cpf=XXX` - Consultar CPF
- `GET /api/consultas?tipo=nome&q=NOME` - Buscar por nome
- `GET /api/consultas?tipo=numero&q=NUMERO` - Buscar por número

### Mídia
- `GET /api/media/nsfw?prompt=PROMPT&apikey=KEY` - Gerar imagem NSFW
- `GET /api/media/video?prompt=PROMPT&apikey=KEY` - Gerar vídeo

### Buscas
- `GET /api/search/github?username=USER&apikey=KEY` - GitHub
- `GET /api/search/gimage?q=QUERY&apikey=KEY` - Google Images
- `GET /api/search/pinterest?q=QUERY&apikey=KEY` - Pinterest
- `GET /api/search/roblox?username=USER&apikey=KEY` - Roblox
- `GET /api/search/tiktok?username=USER&apikey=KEY` - TikTok
- `GET /api/search/youtube?q=QUERY&apikey=KEY` - YouTube

### Sistema
- `GET /` - Informações da API
- `GET /api/status` - Status do servidor

## 🛠️ Criar Novo Endpoint

Crie um arquivo em `endpoints/seu-endpoint.js`:

```javascript
module.exports = {
  name: 'seu-endpoint',
  routes: {
    'GET /api/seu-endpoint': async (req, res, query) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        sucesso: true,
        mensagem: 'Seu endpoint funciona!',
        criador: '@MutanoX'
      }, null, 2));
    }
  }
};
```

O servidor detectará automaticamente e carregará o novo endpoint!

## 📊 Logs

Os logs são salvos em `logs/mutano-x-YYYY-MM-DD.log` e exibidos no console com cores.

Níveis de log:
- `SUCCESS` - Operação bem-sucedida (verde)
- `ERROR` - Erro (vermelho)
- `WARNING` - Aviso (amarelo)
- `INFO` - Informação (ciano)
- `DEBUG` - Debug (magenta)
- `API` - Requisições HTTP (azul)

## 📦 Hospedagem de Mídia

Quando uma imagem NSFW é gerada:

1. API externa retorna URL da imagem
2. Sistema faz download da imagem
3. Salva localmente em `nsfw-gen/`
4. Retorna URL local: `https://mutano-x.discloud.app/api/uploads/nsfw/[uid].[ext]`

## 🔄 Rate Limiting

- **Standard**: 30 requisições/minuto
- **Premium**: 500 requisições/5 minutos
- **Admin**: Ilimitado

## 📝 Exemplos de Uso

### Gerar Imagem NSFW
```bash
curl "http://localhost:8080/api/media/nsfw?prompt=beautiful+sunset&apikey=MutanoX-xxxxx"
```

### Buscar no GitHub
```bash
curl "http://localhost:8080/api/search/github?username=torvalds&apikey=MutanoX-xxxxx"
```

### Consultar CPF
```bash
curl "http://localhost:8080/api/consultas?tipo=cpf&cpf=12345678900&apikey=MutanoX-xxxxx"
```

## 🔒 Segurança

- Validação de API Key em todas as requisições
- Rate limiting por chave
- Logs detalhados de todas as operações
- Chave admin protegida
- CORS configurável

## 📄 Licença

MIT - @MutanoX

## 🤝 Contribuindo

Para adicionar novos endpoints, crie um arquivo em `endpoints/` seguindo o padrão estabelecido.

---

**Criado com ❤️ por @MutanoX**
