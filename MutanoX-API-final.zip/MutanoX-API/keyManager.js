/**
 * Gerenciador de API Keys - MutanoX API
 * @author @MutanoX
 */

const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const config = require('./config');
const logger = require('./logger');

const KEYS_FILE = path.join(__dirname, 'api-keys.json');

class KeyManager {
  constructor() {
    this.keys = this.loadKeys();
    this.requestCounts = {}; // { keyId: { count: 0, resetTime: timestamp } }
  }

  loadKeys() {
    try {
      if (fs.existsSync(KEYS_FILE)) {
        const data = fs.readFileSync(KEYS_FILE, 'utf8');
        return JSON.parse(data);
      }
    } catch (error) {
      logger.error('Erro ao carregar chaves de API', error.message);
    }

    // Chave admin padrão
    return {
      [config.ADMIN_KEY]: {
        id: config.ADMIN_KEY,
        key: config.ADMIN_KEY,
        name: 'Admin Key',
        type: 'admin',
        rateLimit: 'unlimited',
        requestLimit: 'unlimited',
        createdAt: new Date().toISOString(),
        isActive: true
      }
    };
  }

  saveKeys() {
    try {
      fs.writeFileSync(KEYS_FILE, JSON.stringify(this.keys, null, 2));
      logger.debug('Chaves de API salvas com sucesso');
    } catch (error) {
      logger.error('Erro ao salvar chaves de API', error.message);
    }
  }

  generateKey() {
    const uid = uuidv4().replace(/-/g, '').substring(0, 16);
    return `MutanoX-${uid}`;
  }

  createKey(name, type = 'standard', rateLimit = 30, requestLimit = 1000) {
    const key = this.generateKey();
    
    this.keys[key] = {
      id: key,
      key: key,
      name: name || `Key ${key.substring(0, 8)}`,
      type: type, // 'admin', 'standard', 'premium'
      rateLimit: rateLimit, // requests por minuto
      requestLimit: requestLimit, // limite total de requisições
      createdAt: new Date().toISOString(),
      isActive: true,
      requestCount: 0,
      lastReset: new Date().toISOString()
    };

    this.saveKeys();
    logger.success(`Nova chave de API criada: ${key}`, { name, type, rateLimit, requestLimit });
    
    return this.keys[key];
  }

  getKey(key) {
    return this.keys[key] || null;
  }

  validateKey(key) {
    const keyData = this.getKey(key);
    
    if (!keyData) {
      return { valid: false, error: 'Chave de API inválida' };
    }

    if (!keyData.isActive) {
      return { valid: false, error: 'Chave de API desativada' };
    }

    return { valid: true, keyData };
  }

  checkRateLimit(key) {
    const keyData = this.getKey(key);
    
    if (!keyData) {
      return { allowed: false, error: 'Chave inválida' };
    }

    // Admin key sem limite
    if (keyData.type === 'admin') {
      return { allowed: true };
    }

    const now = Date.now();
    const keyId = keyData.id;

    // Inicializar contador se não existir
    if (!this.requestCounts[keyId]) {
      this.requestCounts[keyId] = {
        count: 0,
        resetTime: now + 60000 // 1 minuto
      };
    }

    const counter = this.requestCounts[keyId];

    // Resetar contador se passou o tempo
    if (now > counter.resetTime) {
      counter.count = 0;
      counter.resetTime = now + 60000;
    }

    // Verificar limite
    const limit = keyData.type === 'premium' ? 500 : keyData.rateLimit;
    
    if (counter.count >= limit) {
      return { 
        allowed: false, 
        error: `Limite de requisições atingido (${limit}/min)`,
        retryAfter: Math.ceil((counter.resetTime - now) / 1000)
      };
    }

    counter.count++;
    return { allowed: true, remaining: limit - counter.count };
  }

  deactivateKey(key) {
    const keyData = this.getKey(key);
    
    if (!keyData) {
      return { success: false, error: 'Chave não encontrada' };
    }

    keyData.isActive = false;
    this.saveKeys();
    logger.info(`Chave desativada: ${key}`);
    
    return { success: true };
  }

  activateKey(key) {
    const keyData = this.getKey(key);
    
    if (!keyData) {
      return { success: false, error: 'Chave não encontrada' };
    }

    keyData.isActive = true;
    this.saveKeys();
    logger.info(`Chave ativada: ${key}`);
    
    return { success: true };
  }

  deleteKey(key) {
    if (key === config.ADMIN_KEY) {
      return { success: false, error: 'Não é possível deletar a chave admin' };
    }

    if (this.keys[key]) {
      delete this.keys[key];
      delete this.requestCounts[key];
      this.saveKeys();
      logger.info(`Chave deletada: ${key}`);
      return { success: true };
    }

    return { success: false, error: 'Chave não encontrada' };
  }

  listKeys(adminKey) {
    // Apenas admin pode listar chaves
    if (adminKey !== config.ADMIN_KEY) {
      return { success: false, error: 'Acesso negado' };
    }

    const keysList = Object.values(this.keys).map(k => ({
      id: k.id,
      name: k.name,
      type: k.type,
      rateLimit: k.rateLimit,
      requestLimit: k.requestLimit,
      isActive: k.isActive,
      createdAt: k.createdAt
    }));

    return { success: true, keys: keysList };
  }

  updateKey(key, updates, adminKey) {
    // Apenas admin pode atualizar chaves
    if (adminKey !== config.ADMIN_KEY) {
      return { success: false, error: 'Acesso negado' };
    }

    const keyData = this.getKey(key);
    
    if (!keyData) {
      return { success: false, error: 'Chave não encontrada' };
    }

    // Permitir atualizar apenas certos campos
    if (updates.name) keyData.name = updates.name;
    if (updates.rateLimit !== undefined) keyData.rateLimit = updates.rateLimit;
    if (updates.requestLimit !== undefined) keyData.requestLimit = updates.requestLimit;

    this.saveKeys();
    logger.info(`Chave atualizada: ${key}`, updates);
    
    return { success: true, keyData };
  }
}

module.exports = new KeyManager();
