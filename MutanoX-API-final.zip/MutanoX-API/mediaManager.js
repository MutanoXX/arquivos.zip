/**
 * Gerenciador de Mídia - MutanoX API
 * Download e hospedagem local de imagens
 * @author @MutanoX
 */

const fs = require('fs');
const path = require('path');
const { v4: uuidv4 } = require('uuid');
const config = require('./config');
const logger = require('./logger');

class MediaManager {
  constructor() {
    // Criar diretórios se não existirem
    [config.DIRS.NSFW_GEN, config.DIRS.UPLOADS].forEach(dir => {
      if (!fs.existsSync(dir)) {
        fs.mkdirSync(dir, { recursive: true });
        logger.info(`Diretório criado: ${dir}`);
      }
    });
  }

  /**
   * Download de imagem de URL externa e hospedagem local
   * @param {string} imageUrl - URL da imagem
   * @param {string} type - Tipo de mídia (nsfw, gen, etc)
   * @returns {Promise<{success: boolean, localUrl: string, error?: string}>}
   */
  async downloadAndHost(imageUrl, type = 'nsfw') {
    try {
      logger.debug(`Iniciando download de mídia: ${imageUrl}`);

      // Fazer download da imagem
      const response = await fetch(imageUrl, {
        timeout: config.TIMEOUTS.DOWNLOAD,
        headers: {
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36'
        }
      });

      if (!response.ok) {
        throw new Error(`Erro ao baixar imagem: ${response.status}`);
      }

      // Obter extensão da URL
      const urlParts = new URL(imageUrl);
      const pathname = urlParts.pathname;
      let extension = path.extname(pathname) || '.png';

      // Se não houver extensão, tentar obter do content-type
      if (extension === '' || extension === '.') {
        const contentType = response.headers.get('content-type');
        if (contentType?.includes('jpeg')) extension = '.jpg';
        else if (contentType?.includes('png')) extension = '.png';
        else if (contentType?.includes('gif')) extension = '.gif';
        else if (contentType?.includes('webp')) extension = '.webp';
        else extension = '.png';
      }

      // Gerar ID único para a mídia
      const mediaId = uuidv4().replace(/-/g, '').substring(0, 12);
      const filename = `${mediaId}${extension}`;

      // Determinar diretório de destino
      const destDir = type === 'nsfw' ? config.DIRS.NSFW_GEN : config.DIRS.UPLOADS;
      const filepath = path.join(destDir, filename);

      // Converter response para buffer
      const buffer = await response.arrayBuffer();
      
      // Salvar arquivo
      fs.writeFileSync(filepath, Buffer.from(buffer));

      logger.success(`Mídia hospedada localmente: ${filename}`, { 
        type, 
        size: buffer.byteLength,
        path: filepath 
      });

      // Retornar URL local
      const localUrl = `${config.UPLOAD_BASE_URL}/${type}/${filename}`;
      
      return {
        success: true,
        localUrl,
        mediaId,
        filename,
        size: buffer.byteLength
      };

    } catch (error) {
      logger.error(`Erro ao fazer download de mídia: ${imageUrl}`, error.message);
      return {
        success: false,
        error: error.message || 'Erro ao fazer download da imagem'
      };
    }
  }

  /**
   * Obter informações de uma mídia hospedada
   */
  getMediaInfo(mediaId) {
    // Procurar em ambos os diretórios
    const dirs = [config.DIRS.NSFW_GEN, config.DIRS.UPLOADS];
    
    for (const dir of dirs) {
      const files = fs.readdirSync(dir);
      const file = files.find(f => f.startsWith(mediaId));
      
      if (file) {
        const filepath = path.join(dir, file);
        const stats = fs.statSync(filepath);
        return {
          found: true,
          filename: file,
          size: stats.size,
          createdAt: stats.birthtime,
          path: filepath
        };
      }
    }

    return { found: false };
  }

  /**
   * Limpar mídia antiga (mais de X dias)
   */
  cleanOldMedia(daysOld = 30) {
    const now = Date.now();
    const maxAge = daysOld * 24 * 60 * 60 * 1000;
    let deletedCount = 0;

    const dirs = [config.DIRS.NSFW_GEN, config.DIRS.UPLOADS];

    dirs.forEach(dir => {
      if (!fs.existsSync(dir)) return;

      fs.readdirSync(dir).forEach(file => {
        const filepath = path.join(dir, file);
        const stats = fs.statSync(filepath);
        
        if (now - stats.mtimeMs > maxAge) {
          fs.unlinkSync(filepath);
          deletedCount++;
        }
      });
    });

    if (deletedCount > 0) {
      logger.info(`Mídia antiga removida: ${deletedCount} arquivos`);
    }

    return deletedCount;
  }

  /**
   * Obter estatísticas de armazenamento
   */
  getStorageStats() {
    const dirs = [config.DIRS.NSFW_GEN, config.DIRS.UPLOADS];
    let totalSize = 0;
    let fileCount = 0;

    dirs.forEach(dir => {
      if (!fs.existsSync(dir)) return;

      fs.readdirSync(dir).forEach(file => {
        const filepath = path.join(dir, file);
        const stats = fs.statSync(filepath);
        totalSize += stats.size;
        fileCount++;
      });
    });

    return {
      totalFiles: fileCount,
      totalSize: totalSize,
      totalSizeMB: (totalSize / (1024 * 1024)).toFixed(2)
    };
  }
}

module.exports = new MediaManager();
