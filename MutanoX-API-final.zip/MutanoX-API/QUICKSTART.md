# MutanoX API v2.0 - Quick Start

## 🚀 Começar Rapidamente

### 1. Instalar e Iniciar

```bash
cd MutanoX-API
npm install
npm start
```

O servidor iniciará em `http://localhost:8080`

### 2. Criar sua Primeira API Key

```bash
curl -X POST http://localhost:8080/api/keys/create \
  -H "Content-Type: application/json" \
  -H "X-Admin-Key: MutanoX3397" \
  -d '{
    "name": "Minha Primeira Chave",
    "type": "standard",
    "rateLimit": 30,
    "requestLimit": 1000
  }'
```

Você receberá uma resposta com sua chave no formato: `MutanoX-xxxxxxxxxxxxxxxx`

### 3. Testar um Endpoint

```bash
# Consultar CPF
curl "http://localhost:8080/api/consultas?tipo=cpf&cpf=12345678900&apikey=MutanoX-xxxxxxxxxxxxxxxx"

# Buscar no GitHub
curl "http://localhost:8080/api/search/github?username=torvalds&apikey=MutanoX-xxxxxxxxxxxxxxxx"

# Gerar Imagem NSFW
curl "http://localhost:8080/api/media/nsfw?prompt=beautiful+sunset&apikey=MutanoX-xxxxxxxxxxxxxxxx"
```

## 📋 Chaves Disponíveis

### Admin Key (Ilimitada)
```
MutanoX3397
```

Use para gerenciar outras chaves:
```bash
# Listar todas as chaves
curl "http://localhost:8080/api/keys/list?adminkey=MutanoX3397"

# Deletar uma chave
curl -X DELETE "http://localhost:8080/api/keys/delete?adminkey=MutanoX3397&key=MutanoX-xxxxxxxxxxxxxxxx"
```

## 🔌 Endpoints Principais

| Endpoint | Descrição |
|----------|-----------|
| `GET /api/consultas?tipo=cpf&cpf=XXX` | Consultar CPF |
| `GET /api/consultas?tipo=nome&q=NOME` | Buscar por nome |
| `GET /api/consultas?tipo=numero&q=NUMERO` | Buscar por número |
| `GET /api/media/nsfw?prompt=PROMPT` | Gerar imagem NSFW |
| `GET /api/media/video?prompt=PROMPT` | Gerar vídeo |
| `GET /api/search/github?username=USER` | Buscar GitHub |
| `GET /api/search/gimage?q=QUERY` | Google Images |
| `GET /api/search/pinterest?q=QUERY` | Pinterest |
| `GET /api/search/roblox?username=USER` | Roblox |
| `GET /api/search/tiktok?username=USER` | TikTok |
| `GET /api/search/youtube?q=QUERY` | YouTube |

## 🛠️ Adicionar Novo Endpoint

1. Crie um arquivo em `endpoints/seu-endpoint.js`:

```javascript
module.exports = {
  name: 'seu-endpoint',
  routes: {
    'GET /api/seu-endpoint': async (req, res, query) => {
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({
        sucesso: true,
        mensagem: 'Seu endpoint funciona!',
        criador: '@MutanoX'
      }, null, 2));
    }
  }
};
```

2. O servidor detectará e carregará automaticamente!

## 📊 Tipos de Chaves

| Tipo | Rate Limit | Uso |
|------|-----------|-----|
| **standard** | 30/min | Desenvolvimento |
| **premium** | 500/5min | Produção |
| **admin** | Ilimitado | Gerenciamento |

## 🔐 Segurança

- Todas as requisições requerem API Key (exceto `/` e `/api/status`)
- Rate limiting automático
- Logs detalhados de todas as operações
- Chave admin protegida

## 📁 Estrutura

```
MutanoX-API/
├── index.js           # Servidor principal
├── config.js          # Configurações
├── logger.js          # Sistema de logs
├── keyManager.js      # Gerenciador de chaves
├── mediaManager.js    # Gerenciador de mídia
├── endpoints/         # Seus endpoints aqui
├── nsfw-gen/          # Imagens geradas
├── uploads/           # Uploads
└── logs/              # Logs do servidor
```

## 🐛 Troubleshooting

### Porta já em uso
```bash
# Mude a porta em config.js
PORT: 3000
```

### Erro ao carregar endpoints
- Verifique se o arquivo está em `endpoints/`
- Verifique a sintaxe JavaScript
- Veja os logs para mais detalhes

### Chave rejeitada
- Verifique se a chave está ativa: `curl "http://localhost:8080/api/keys/list?adminkey=MutanoX3397"`
- Verifique o rate limit

## 📝 Exemplo Completo

```bash
# 1. Criar chave
KEY=$(curl -s -X POST http://localhost:8080/api/keys/create \
  -H "Content-Type: application/json" \
  -H "X-Admin-Key: MutanoX3397" \
  -d '{"name":"Test","type":"standard"}' | grep -o '"key":"[^"]*' | cut -d'"' -f4)

# 2. Usar a chave
curl "http://localhost:8080/api/search/github?username=linus&apikey=$KEY"

# 3. Verificar status
curl "http://localhost:8080/api/status?apikey=$KEY"
```

## 🎯 Próximos Passos

1. Explore os endpoints disponíveis
2. Crie suas próprias chaves de API
3. Adicione novos endpoints conforme necessário
4. Configure o rate limiting para suas necessidades
5. Monitore os logs em `logs/`

---

**Criado com ❤️ por @MutanoX**
