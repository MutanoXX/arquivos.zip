/**
 * Sistema de Logs Decorado - MutanoX API
 * @author @MutanoX
 */

const fs = require('fs');
const path = require('path');
const config = require('./config');

// Criar diretório de logs se não existir
if (!fs.existsSync(config.DIRS.LOGS)) {
  fs.mkdirSync(config.DIRS.LOGS, { recursive: true });
}

const COLORS = {
  RESET: '\x1b[0m',
  BRIGHT: '\x1b[1m',
  DIM: '\x1b[2m',
  
  // Cores
  BLACK: '\x1b[30m',
  RED: '\x1b[31m',
  GREEN: '\x1b[32m',
  YELLOW: '\x1b[33m',
  BLUE: '\x1b[34m',
  MAGENTA: '\x1b[35m',
  CYAN: '\x1b[36m',
  WHITE: '\x1b[37m',
  
  // Background
  BG_RED: '\x1b[41m',
  BG_GREEN: '\x1b[42m',
  BG_YELLOW: '\x1b[43m',
  BG_BLUE: '\x1b[44m',
  BG_MAGENTA: '\x1b[45m',
  BG_CYAN: '\x1b[46m'
};

const SYMBOLS = {
  SUCCESS: '✓',
  ERROR: '✗',
  WARNING: '⚠',
  INFO: 'ℹ',
  DEBUG: '◆',
  ARROW: '→',
  STAR: '★',
  DIAMOND: '◆',
  CLOCK: '⏱',
  SHIELD: '🔐'
};

class Logger {
  constructor() {
    this.logFile = path.join(config.DIRS.LOGS, `mutano-x-${new Date().toISOString().split('T')[0]}.log`);
  }

  getTimestamp() {
    const now = new Date();
    return now.toLocaleTimeString('pt-BR', { 
      hour12: false,
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit',
      fractionalSecondDigits: 3
    });
  }

  writeToFile(message) {
    const timestamp = new Date().toISOString();
    const cleanMessage = message.replace(/\x1b\[[0-9;]*m/g, ''); // Remove ANSI codes
    fs.appendFileSync(this.logFile, `[${timestamp}] ${cleanMessage}\n`);
  }

  formatMessage(level, symbol, color, message, details = null) {
    const timestamp = this.getTimestamp();
    const header = `${color}${SYMBOLS[symbol]} [${level}] ${COLORS.RESET}${COLORS.DIM}${timestamp}${COLORS.RESET}`;
    const body = `${color}${message}${COLORS.RESET}`;
    
    let output = `${header} ${body}`;
    
    if (details) {
      if (typeof details === 'object') {
        details = JSON.stringify(details, null, 2);
      }
      output += `\n${COLORS.DIM}${details}${COLORS.RESET}`;
    }
    
    return output;
  }

  success(message, details = null) {
    const formatted = this.formatMessage('SUCCESS', 'SUCCESS', COLORS.GREEN, message, details);
    console.log(formatted);
    this.writeToFile(`[SUCCESS] ${message} ${details ? JSON.stringify(details) : ''}`);
  }

  error(message, details = null) {
    const formatted = this.formatMessage('ERROR', 'ERROR', COLORS.RED, message, details);
    console.error(formatted);
    this.writeToFile(`[ERROR] ${message} ${details ? JSON.stringify(details) : ''}`);
  }

  warning(message, details = null) {
    const formatted = this.formatMessage('WARNING', 'WARNING', COLORS.YELLOW, message, details);
    console.warn(formatted);
    this.writeToFile(`[WARNING] ${message} ${details ? JSON.stringify(details) : ''}`);
  }

  info(message, details = null) {
    const formatted = this.formatMessage('INFO', 'INFO', COLORS.CYAN, message, details);
    console.log(formatted);
    this.writeToFile(`[INFO] ${message} ${details ? JSON.stringify(details) : ''}`);
  }

  debug(message, details = null) {
    const formatted = this.formatMessage('DEBUG', 'DEBUG', COLORS.MAGENTA, message, details);
    console.log(formatted);
    this.writeToFile(`[DEBUG] ${message} ${details ? JSON.stringify(details) : ''}`);
  }

  api(method, path, statusCode, details = null) {
    const statusColor = statusCode >= 200 && statusCode < 300 ? COLORS.GREEN : 
                        statusCode >= 400 && statusCode < 500 ? COLORS.YELLOW : 
                        statusCode >= 500 ? COLORS.RED : COLORS.BLUE;
    
    const timestamp = this.getTimestamp();
    const message = `${COLORS.BRIGHT}${COLORS.BLUE}${SYMBOLS.ARROW}${COLORS.RESET} ${COLORS.DIM}${timestamp}${COLORS.RESET} ${COLORS.BRIGHT}${method}${COLORS.RESET} ${COLORS.CYAN}${path}${COLORS.RESET} ${statusColor}${statusCode}${COLORS.RESET}`;
    
    console.log(message);
    this.writeToFile(`[API] ${method} ${path} ${statusCode}`);
  }

  separator() {
    const line = '═'.repeat(70);
    console.log(`${COLORS.DIM}${line}${COLORS.RESET}`);
  }

  banner(text) {
    const padding = Math.max(0, (70 - text.length) / 2);
    const line = '═'.repeat(70);
    console.log(`${COLORS.BRIGHT}${COLORS.CYAN}╔${line}╗${COLORS.RESET}`);
    console.log(`${COLORS.BRIGHT}${COLORS.CYAN}║${' '.repeat(padding)}${text}${' '.repeat(Math.ceil(padding))}║${COLORS.RESET}`);
    console.log(`${COLORS.BRIGHT}${COLORS.CYAN}╚${line}╝${COLORS.RESET}`);
  }
}

module.exports = new Logger();
